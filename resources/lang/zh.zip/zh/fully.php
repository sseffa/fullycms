<?php

return array(

    /* footer start */
    'newsletter'          => '联系我们',
    'button_save'         => '确定',
    'enter_your_email'    => '请输入你的邮箱',
    'all_rights_reserved' => 'All Rights Reserved',
    /* footer end */
    /* contact page start */
    'contact_form'        => '联系我们',
    'our_location'        => '联系地址',
    'name_and_surname'    => '姓名',
    'email'               => '邮箱地址',
    'phone_number'        => '电话',
    'subject'             => '主题',
    'message'             => '详细信息',
    'button_send'         => '发送',
    /* contact page end */

    /*pagination start*/
    'link_previous'       => '上一页',
    'link_next'           => '下一页',/*pagination end*/);